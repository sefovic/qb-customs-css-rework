Config = Config or {}
 
-- ⚠️⚠️FOR RECEIPT SYSTEM PLEASE CHECK shared/locations.lua there you can find some settings that you can change for the receipt system⚠️⚠️

Config.Debug = false -- Set to True to enable Debug Prints
Config.MoneyType = 'bank'
Config.RepairMoneyType = 'cash'
Config.UseRadial = false -- Will use qb-radial menu for entering instead of press E
Config.allowGovPlateIndex = false -- Setting this to true will allow all vehicles to purchase gov plate index "Blue on White #3" (only for emergency vehicles otherwise)
maxVehiclePerformanceUpgrades = 0 -- | All Upgrades: 0 | No Upgrades: -1 | Can be -1 to 4

-- ADJUST PRICING
vehicleCustomisationPrices = {
    cosmetics = {price = 0},
    respray = {price = 0},
    performance = {prices = {0, 0, 0, 0, 0, 0, 0}},
    turbo = {prices = {0, 0}},
    wheels = {price = 0},
    customwheels = {price = 0},
    wheelsmoke = {price = 0},
    windowtint = {price = 0},
    neonside = {price = 0},
    neoncolours = {price = 0},
    headlights = {price = 0},
    xenoncolours = {price = 0},
    oldlivery = {price = 0},
    plateindex = {price = 0}
}

-- WINDOW TINTS

vehicleWindowTintOptions = {
    {name = "Şeffaf", id = 0},
    {name = "Saf Siyah", id = 1},
    {name = "Koyu Duman", id = 2},
    {name = "Açık Duman", id = 3}
}

-- FARLAR

vehicleXenonOptions = {
    xenonColours = {
        {name = "Stok", id = 255},
        {name = "Beyaz", id = 0}, {name = "Mavi", id = 1},
        {name = "Elektrik Mavisi", id = 2},
        {name = "Nane Yeşili", id = 3},
        {name = "Açık Yeşil", id = 4},
        {name = "Sarı", id = 5},
        {name = "Altın Yağmur", id = 6},
        {name = "Turuncu", id = 7},
        {name = "Kırmızı", id = 8},
        {name = "Pembe Midilli", id = 9},
        {name = "Ateş Pembe", id = 10},
        {name = "Mor", id = 11},
        {name = "Siyah Işık", id = 12}
    }
}

-- JANTLAR

vehicleWheelOptions = {
    {category = "Özel Lastikler", id = -1, wheelID = 23},
    {category = "Lastik Dumanı", id = 20, wheelID = 23},
    {category = "Spor", id = 0, wheelID = 23},
    {category = "Kaslı", id = 1, wheelID = 23},
    {category = "Lowrider", id = 2, wheelID = 23},
    {category = "SUV", id = 3, wheelID = 23},
    {category = "Arazi", id = 4, wheelID = 23},
    {category = "Tuning", id = 5, wheelID = 23},
    {category = "Motosiklet", id = 6, wheelID = 23},
    {category = "Lüks", id = 7, wheelID = 23},
    {category = "Benny's Jant", id = 8, wheelID = 23},
    {category = "Bespoke Jant", id = 9, wheelID = 23},
    {category = "Drag Yarış", id = 10, wheelID = 23},
    {category = "Sokak", id = 11, wheelID = 23},
    {category = "Ralli", id = 12, wheelID = 23},
}

-- LASTİK DUMANI

vehicleTyreSmokeOptions = {
    { name = "Beyaz Duman", r = 254, g = 254, b = 254},
    { name = "Siyah Duman", r = 1, g = 1, b = 1},
    { name = "Mavi Duman", r = 0, g = 150, b = 255},
    { name = "Sarı Duman", r = 255, g = 255, b = 50},
    { name = "Turuncu Duman", r = 255, g = 153, b = 51},
    { name = "Kırmızı Duman", r = 255, g = 10, b = 10},
    { name = "Yeşil Duman", r = 10, g = 255, b = 10},
    { name = "Mor Duman", r = 153, g = 10, b = 153},
    { name = "Pembe Duman", r = 255, g = 102, b = 178},
    { name = "Gri Duman", r = 128, g = 128, b = 128}
}

-- NEONLAR

vehicleNeonOptions = {
    category = "Neonlar",
    neonTypes = {
        {name = "Ön Neon", id = 2},
        {name = "Arka Neon", id = 3},
        {name = "Sol Neon", id = 0},
        {name = "Sağ Neon", id = 1}
    },
    neonColours = {
        { name = "Beyaz", r = 222, g = 222, b = 255},
        { name = "Mavi", r = 2, g = 21, b = 255},
        { name = "Elektrik Mavisi", r = 3, g = 83, b = 255},
        { name = "Nane Yeşili", r = 0, g = 255, b = 140},
        { name = "Açık Yeşil", r = 94, g = 255, b = 1},
        { name = "Sarı", r = 255, g = 255, b = 0},
        { name = "Altın Yağmur", r = 255, g = 150, b = 0},
        { name = "Turuncu", r = 255, g = 62, b = 0},
        { name = "Kırmızı", r = 255, g = 1, b = 1},
        { name = "Pembe Midilli", r = 255, g = 50, b = 100},
        { name = "Ateş Pembe", r = 255, g = 5, b = 190},
        { name = "Mor", r = 35, g = 1, b = 255},
        { name = "Siyah Işık", r = 15, g = 3, b = 255}
    }
}

-- ANA BİLEŞENLER

vehicleCustomisation = {
    {category = "Spoiler", id = 0},
    {category = "Ön Tampon", id = 1},
    {category = "Arka Tampon", id = 2},
    {category = "Yan Etek", id = 3},
    {category = "Egzoz", id = 4},
    {category = "Roll Cage", id = 5},
    {category = "Izgara", id = 6},
    {category = "Kaput", id = 7},
    {category = "Sol Çamurluk", id = 8},
    {category = "Sağ Çamurluk", id = 9},
    {category = "Tavan", id = 10},
    {category = "Motor Yükseltme", id = 11},
    {category = "Fren Yükseltme", id = 12},
    {category = "Vites Kutusu Yükseltme", id = 13},
    {category = "Süspansiyon Yükseltme", id = 15},
    {category = "Zırh Yükseltme", id = 16},
    {category = "Turbo Yükseltme", id = 18},
    {category = "Özel Plakalar", id = 25},
    {category = "Trim A", id = 27},
    {category = "Süslemeler", id = 28},
    {category = "Gösterge Paneli", id = 29},
    {category = "Gösterge", id = 30},
    {category = "Kapı Hoparlörü", id = 31},
    {category = "Koltuklar", id = 32},
    {category = "Direksiyon", id = 33},
    {category = "Vites Kolu", id = 34},
    {category = "Plaka", id = 35},
    {category = "Hoparlör", id = 36},
    {category = "Bagaj", id = 37},
    {category = "Hidrolik", id = 38},
    {category = "Motor Bloğu", id = 39},
    {category = "Hava Filtresi", id = 40},
    {category = "Amortisör", id = 41},
    {category = "Kemer Kapağı", id = 42},
    {category = "Anten", id = 43},
    {category = "Trim B", id = 44},
    {category = "Yakıt Deposu", id = 45},
    {category = "Cam", id = 46},
    {category = "Kaplama", id = 48},
    {category = "Kornalar", id = 14,
        hornNames = {
            {name = "Kamyon Kornası", id = 0},
            {name = "Polis Kornası", id = 1},
            {name = "Palyaço Kornası", id = 2},
            {name = "Müzikli Korna 1", id = 3},
            {name = "Müzikli Korna 2", id = 4},
            {name = "Müzikli Korna 3", id = 5},
            {name = "Müzikli Korna 4", id = 6},
            {name = "Müzikli Korna 5", id = 7},
            {name = "Üzgün Trombon", id = 8},
            {name = "Klasik Korna 1", id = 9},
            {name = "Klasik Korna 2", id = 10},
            {name = "Klasik Korna 3", id = 11},
            {name = "Klasik Korna 4", id = 12},
            {name = "Klasik Korna 5", id = 13},
            {name = "Klasik Korna 6", id = 14},
            {name = "Klasik Korna 7", id = 15},
            {name = "Nota - Do", id = 16},
            {name = "Nota - Re", id = 17},
            {name = "Nota - Mi", id = 18},
            {name = "Nota - Fa", id = 19},
            {name = "Nota - Sol", id = 20},
            {name = "Nota - La", id = 21},
            {name = "Nota - Si", id = 22},
            {name = "Nota - Do", id = 23},
            {name = "Caz Kornası 1", id = 24},
            {name = "Caz Kornası 2", id = 25},
            {name = "Caz Kornası 3", id = 26},
            {name = "Caz Döngü", id = 27},
            {name = "Amerikan Marşı 1", id = 28},
            {name = "Amerikan Marşı 2", id = 29},
            {name = "Amerikan Marşı 3", id = 30},
            {name = "Amerikan Marşı 4", id = 31},
            {name = "Klasik Korna 8 Döngü", id = 32},
            {name = "Klasik Korna 9 Döngü", id = 33},
            {name = "Klasik Korna 10 Döngü", id = 34},
            {name = "Klasik Korna 8", id = 35},
            {name = "Klasik Korna 9", id = 36},
            {name = "Klasik Korna 10", id = 37},
            {name = "Cenaze Döngü", id = 38},
            {name = "Cenaze", id = 39},
            {name = "Korkutucu Döngü", id = 40},
            {name = "Korkutucu", id = 41},
            {name = "San Andreas Döngü", id = 42},
            {name = "San Andreas", id = 43},
            {name = "Liberty City Döngü", id = 44},
            {name = "Liberty City", id = 45},
            {name = "Bayram 1 Döngü", id = 46},
            {name = "Bayram 1", id = 47},
            {name = "Bayram 2 Döngü", id = 48},
            {name = "Bayram 2", id = 49},
            {name = "Bayram 3 Döngü", id = 50},
            {name = "Bayram 3", id = 51}
        }
    }
}

-- RENKLER

vehicleResprayOptions = {
    {category = "Klasik", id = 0,
        colours = {
            {name = "Siyah", id = 0},
            {name = "Karbon Siyahı", id = 147},
            {name = "Grafit", id = 1},
            {name = "Antrasit Siyah", id = 11},
            {name = "Siyah Çelik", id = 11},
            {name = "Koyu Çelik", id = 3},
            {name = "Gümüş", id = 4},
            {name = "Mavimsi Gümüş", id = 5},
            {name = "Lamineli Çelik", id = 6},
            {name = "Gölge Gümüş", id = 7},
            {name = "Taş Gümüş", id = 8},
            {name = "Geceyarısı Gümüş", id = 9},
            {name = "Dökme Demir Gümüş", id = 10},
            {name = "Kırmızı", id = 27},
            {name = "Torino Kırmızı", id = 28},
            {name = "Formula Kırmızı", id = 29},
            {name = "Lav Kırmızı", id = 150},
            {name = "Alev Kırmızı", id = 30},
            {name = "Asil Kırmızı", id = 31},
            {name = "Garnet Kırmızı", id = 32},
            {name = "Günbatımı Kırmızı", id = 33},
            {name = "Şarap Kırmızı", id = 34},
            {name = "Bordo", id = 143},
            {name = "Şeker Kırmızı", id = 35},
            {name = "Ateş Pembesi", id = 135},
            {name = "Pfister Pembesi", id = 137},
            {name = "Somon Pembesi", id = 136},
            {name = "Gün Doğumu Turuncusu", id = 36},
            {name = "Turuncu", id = 38},
            {name = "Parlak Turuncu", id = 138},
            {name = "Altın", id = 99},
            {name = "Bronz", id = 90},
            {name = "Sarı", id = 88},
            {name = "Yarış Sarısı", id = 89},
            {name = "Çiy Sarısı", id = 91},
            {name = "Koyu Yeşil", id = 49},
            {name = "Yarış Yeşili", id = 50},
            {name = "Deniz Yeşili", id = 51},
            {name = "Zeytin Yeşili", id = 52},
            {name = "Açık Yeşil", id = 53},
            {name = "Benzin Yeşili", id = 54},
            {name = "Lime Yeşili", id = 92},
            {name = "Geceyarısı Mavisi", id = 141},
            {name = "Galaksi Mavisi", id = 61},
            {name = "Koyu Mavi", id = 62},
            {name = "Sakson Mavisi", id = 63},
            {name = "Mavi", id = 64},
            {name = "Denizci Mavisi", id = 65},
            {name = "Liman Mavisi", id = 66},
            {name = "Elmas Mavisi", id = 67},
            {name = "Sörf Mavisi", id = 68},
            {name = "Nautik Mavi", id = 69},
            {name = "Yarış Mavisi", id = 73},
            {name = "Ultra Mavi", id = 70},
            {name = "Açık Mavi", id = 74},
            {name = "Çikolata Kahverengi", id = 96},
            {name = "Bizon Kahverengi", id = 101},
            {name = "Krem Kahverengi", id = 95},
            {name = "Feltzer Kahverengi", id = 94},
            {name = "Akçaağaç Kahverengi", id = 97},
            {name = "Kayın Kahverengi", id = 103},
            {name = "Tarçın Kahverengi", id = 104},
            {name = "Eyer Kahverengi", id = 98},
            {name = "Yosun Kahverengi", id = 100},
            {name = "Ahşap Kahverengi", id = 102},
            {name = "Saman Kahverengi", id = 99},
            {name = "Kum Kahverengi", id = 105},
            {name = "Açık Kahverengi", id = 106},
            {name = "Schafter Moru", id = 71},
            {name = "Yelken Moru", id = 72},
            {name = "Geceyarısı Moru", id = 142},
            {name = "Parlak Mor", id = 145},
            {name = "Krem", id = 107},
            {name = "Buz Beyazı", id = 111},
            {name = "Don Beyaz", id = 112}
        }
    },

    {category = "Metalik", id = 1,
        colours = {
            -- Aynı liste yukarıdaki gibi çevrilmiştir, tekrar yazmaya gerek yok. Yukarıdaki listeyi kullan.
        }
    },

    {category = "Mat", id = 2,
        colours = {
            {name = "Siyah", id = 12},
            {name = "Gri", id = 13},
            {name = "Açık Gri", id = 14},
            {name = "Buz Beyazı", id = 131},
            {name = "Mavi", id = 83},
            {name = "Koyu Mavi", id = 82},
            {name = "Geceyarısı Mavisi", id = 84},
            {name = "Geceyarısı Moru", id = 149},
            {name = "Schafter Moru", id = 148},
            {name = "Kırmızı", id = 39},
            {name = "Koyu Kırmızı", id = 40},
            {name = "Turuncu", id = 41},
            {name = "Sarı", id = 42},
            {name = "Lime Yeşili", id = 55},
            {name = "Yeşil", id = 128},
            {name = "Orman Yeşili", id = 151},
            {name = "Yaprak Yeşili", id = 155},
            {name = "Zeytin Kamuflaj", id = 152},
            {name = "Koyu Toprak", id = 153},
            {name = "Çöl Rengi", id = 154}
        }
    },

    {category = "Metal", id = 3,
        colours = {
            {name = "Fırçalanmış Çelik", id = 117},
            {name = "Fırçalanmış Siyah Çelik", id = 118},
            {name = "Fırçalanmış Alüminyum", id = 119},
            {name = "Saf Altın", id = 158},
            {name = "Fırçalanmış Altın", id = 159},
            {name = "Krom", id = 120}
        }
    }
}
