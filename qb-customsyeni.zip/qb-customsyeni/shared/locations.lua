--[[
    ['Innocence'] = {
    settings = {
        label = 'Bennys Motorworks', -- Text label for anything that wants it
        welcomeLabel = "Welcome to Benny's Motorworks!", -- Welcome label in the UI
        enabled = true, -- If the location can be used at all

        ---------- Receipt system ----------
        useReceiptSystem = true,  -- In the case of "useReceiptSystem" = false everyone will need 
        -- pay for evenry modification and all modifications will be saved on the vehicle. 
        -- In the case of "useReceiptSystem = true" only players who don't have any job from list below "saveUpgrades"
        -- will receive a receipt and not have to pay for modifications. 

        
        saveUpgrades = { 
            jobs = {"mechanic"}, -- If a player has some of these jobs, they will need to pay for every 
                                    -- modification, and all will be saved on the vehicle.
            dutyCheck = false, 
        } ,

        upgradesMenuAccess = {
            jobs = {"mechanic"}, -- If a player has some of these jobs, they will have access to the "upgrades menu" - engine upgrades, brake upgrades...
            dutyCheck = false,
        },
        ------------------------------------
    },
    blip = {
        label = 'Bennys Motorworks',
        coords = vector3(-205.6992, -1312.7377, 31.1588),
        sprite = 72,
        scale = 0.65,
        color = 0,
        display = 4,
        enabled = true,
    },
    categories = { -- Only include the categories you want. A category not listed defaults to FALSE.
        mods = true, -- Performance Mods
        repair = true,
        armor = true,
        respray = true,
        liveries = true,
        wheels = true,
        tint = true,
        plate = true,
        extras = true,
        neons = true,
        xenons = true,
        horn = true,
        turbo = true,
        cosmetics = true, -- Cosmetic Mods
    },
    drawtextui = {
        text = "Bennys Motorworks",
    },
    restrictions = { -- A person must pass ALL the restriction checks. Remove an item below to automatically pass that check.
        job = "any", -- Allowed job. Can be an array of strings for multiple jobs. Any for all jobs
        gang = "any", -- Allowed gang. Can be an array of strings for multiple gangs. Any for all gangs
        allowedClasses = {}, -- Array of allowed classes. Empty will allow any but denied classes.
        deniedClasses = {}, -- Array of denied classes.
    },
    zones = {
        { coords = vector3(-212.55, -1320.56, 31.0), length = 6.0, width = 4.0, heading = 270.0, minZ = 29.88, maxZ = 33.48 },
        { coords = vector3(-222.47, -1329.73, 31.0), length = 6.0, width = 4.4, heading = 270.0, minZ = 29.88, maxZ = 33.48 },
    }
},

Vehicle Classes:
0: Compacts     1: Sedans       2: SUVs         3: Coupes       4: Muscle       5: Sports Classics
6: Sports       7: Super        8: Motorcycles  9: Off-road     10: Industrial  11: Utility
12: Vans        13: Cycles      14: Boats       15: Helicopters 16: Planes      17: Service
18: Emergency   19: Military    20: Commercial  21: Trains
 ]]




 
Config = Config or {}

Config.Locations = {
    ['bennys'] = {
        settings = {
            label = 'Bennys Motorworks',
            welcomeLabel = "Bennys Mekanik Hoşgeldin",
            enabled = true,
            ---------- Receipt system ----------
            useReceiptSystem = false,  -- In the case of "useReceiptSystem" = false everyone will need 
            -- pay for every modification and all modifications will be saved on the vehicle. 
            -- In the case of "useReceiptSystem = true" only players who don't have any job from list below "saveUpgrades"
            -- will receive a receipt and not have to pay for modifications. 

            
            saveUpgrades = { 
                jobs = {"mechanic"}, -- If a player has some of these jobs, they will need to pay for every 
                                     -- modification, and all will be saved on the vehicle.
                dutyCheck = false, 
            },

            upgradesMenuAccess = {
                jobs = {"mechanic"}, -- If a player has some of these jobs, they will have access to the "upgrades menu" - engine upgrades, brake upgrades...
                dutyCheck = false,
            },
            ------------------------------------
        },
        blip = {
            label = 'Kiralık Mekanik',
            coords = vector3(-205.6992, -1312.7377, 31.1588),
            sprite = 446,
            scale = 0.65,
            color = 1,
            display = 4,
            enabled = false,
        },
        categories = {
            mods = true,
            turbo = true,
            repair = true,
            respray = true,
            liveries = true,
            wheels = true,
            tint = true,
            plate = true,
            extras = true,
            neons = true,
            xenons = true,
            horn = true,
            cosmetics = true,
        },
        drawtextui = {
            text = "Mekanik Alanı"
        },
        restrictions = {
            job = { 'mechanic'},
             },
        zones = {
            { coords = vector3(-212.55, -1320.56, 31.0), length = 6.0, width = 4.0, heading = 270.0, minZ = 29.88, maxZ = 33.48 },
            { coords = vector3(-222.47, -1329.73, 31.0), length = 6.0, width = 4.0, heading = 270.0, minZ = 29.88, maxZ = 33.48 },
        }
    },

    ['lscustoms'] = {
        settings = {
            label = 'LS Customs Mekanik',
            welcomeLabel = "LS Customs Mekaniğe Hoşgeldiniz!",
            enabled = true,
            ---------- Receipt system ----------
            useReceiptSystem = false,  -- In the case of "useReceiptSystem" = false everyone will need 
            -- pay for evenry modification and all modifications will be saved on the vehicle. 
            -- In the case of "useReceiptSystem = true" only players who don't have any job from list below "saveUpgrades"
            -- will receive a receipt and not have to pay for modifications. 

            
            saveUpgrades = { 
                jobs = {"mechanic2"}, -- If a player has some of these jobs, they will need to pay for every 
                                     -- modification, and all will be saved on the vehicle.
                dutyCheck = false, 
            } ,

            upgradesMenuAccess = {
                jobs = {"mechanic2"}, -- If a player has some of these jobs, they will have access to the "upgrades menu" - engine upgrades, brake upgrades...
                dutyCheck = false,
            },
            ------------------------------------
        },
        blip = {
            label = 'Kiralık Mekanik',
            coords = vector3(-357.78, -126.0, 38.7),
            sprite = 446,
            scale = 0.65,
            color = 1,
            display = 4,
            enabled = false,
        },
        categories = {
            mods = true,
            turbo = true,
            repair = true,
            respray = true,
            liveries = true,
            wheels = true,
            tint = true,
            plate = true,
            extras = true,
            neons = true,
            xenons = true,
            horn = true,
            cosmetics = true,
        },
        drawtextui = {
            text = "Mekanik Alanı"
        },
        restrictions = {
            job = { 'mechanic2'},
         },
        zones = {
            { coords = vector3(-326.78, -144.32, 39.02), length = 6.0, width = 4.0, heading = 69.29, minZ = 37.0, maxZ = 41.0 },
            { coords = vector3(-324.73, -139.22, 39.02), length = 6.0, width = 4.0, heading = 70.53, minZ = 37.0, maxZ = 41.0 },
            { coords = vector3(-323.1, -133.98, 39.02), length = 6.0, width = 4.0, heading = 64.44, minZ = 37.0, maxZ = 41.0 },
            { coords = vector3(-321.21, -128.79, 39.02), length = 6.0, width = 4.0, heading = 66.46, minZ = 37.0, maxZ = 41.0 },
        }
    },

    ['domestic'] = {
        settings = {
            label = 'Domestic Mekanik',
            welcomeLabel = "Domestic Mekaniğe Hoşgeldiniz!",
            enabled = true,
            ---------- Receipt system ----------
            useReceiptSystem = false,  -- In the case of "useReceiptSystem" = false everyone will need 
            -- pay for evenry modification and all modifications will be saved on the vehicle. 
            -- In the case of "useReceiptSystem = true" only players who don't have any job from list below "saveUpgrades"
            -- will receive a receipt and not have to pay for modifications. 

            
            saveUpgrades = { 
                jobs = {"mechanic3"}, -- If a player has some of these jobs, they will need to pay for every 
                                     -- modification, and all will be saved on the vehicle.
                dutyCheck = false, 
            } ,

            upgradesMenuAccess = {
                jobs = {"mechanic3"}, -- If a player has some of these jobs, they will have access to the "upgrades menu" - engine upgrades, brake upgrades...
                dutyCheck = false,
            },
            ------------------------------------
        },
        blip = {
            label = 'Kiralık Mekanik',
            coords = vector3(534.7, -185.46, 53.76),
            sprite = 446,
            scale = 0.65,
            color = 1,
            display = 4,
            enabled = false,
        },
        categories = {
            mods = true,
            turbo = true,
            repair = true,
            respray = true,
            liveries = true,
            wheels = true,
            tint = true,
            plate = true,
            extras = true,
            neons = true,
            xenons = true,
            horn = true,
            cosmetics = true,
        },
        drawtextui = {
            text = "Mekanik Alanı"
        },
        restrictions = {
            job = { 'mechanic3'},
        },
        zones = {
            { coords = vector3(548.33, -197.24, 54.49), length = 6.0, width = 4.0, heading = 177.11, minZ = 52.88, maxZ = 56.48 },
        }
    },


    ['hayesmekanik'] = {
        settings = {
            label = 'Hayes Mekanik',
            welcomeLabel = "Hayes Mekaniğe Hoşgeldiniz!",
            enabled = true,
            ---------- Receipt system ----------
            useReceiptSystem = false,  -- In the case of "useReceiptSystem" = false everyone will need 
            -- pay for evenry modification and all modifications will be saved on the vehicle. 
            -- In the case of "useReceiptSystem = true" only players who don't have any job from list below "saveUpgrades"
            -- will receive a receipt and not have to pay for modifications. 

            
            saveUpgrades = { 
                jobs = {"mechanic5"}, -- If a player has some of these jobs, they will need to pay for every 
                                     -- modification, and all will be saved on the vehicle.
                dutyCheck = false, 
            } ,

            upgradesMenuAccess = {
                jobs = {"mechanic5"}, -- If a player has some of these jobs, they will have access to the "upgrades menu" - engine upgrades, brake upgrades...
                dutyCheck = false,
            },
            ------------------------------------
        },
        blip = {
            label = 'Kiralık Mekanik',
            coords = vector3(-1433.87, -447.76, 35.8),
            sprite = 446,
            scale = 0.65,
            color = 1,
            display = 4,
            enabled = false,
        },
        categories = {
            repair = true,
            turbo = true,
            respray = true,
            liveries = true,
            wheels = true,
            tint = true,
            plate = true,
            extras = true,
            neons = true,
            xenons = true,
            horn = true,
            cosmetics = true,
        },
        drawtextui = {
            text = "Mekanik Alanı"
        },
        restrictions = {
            job = { 'mechanic5'},
        },
        zones = {
            { coords = vector3(-1423.47, -450.28, 35.91), length = 6.0, width = 4.0, heading = 28.35, minZ = 33.88, maxZ = 37.48 },
            { coords = vector3(-1416.74, -447.01, 35.91), length = 6.0, width = 4.0, heading = 31.49, minZ = 33.88, maxZ = 37.48 },
        }
    },


    ['PALETO'] = {
        settings = {
            label = 'PALETO Mekanik',
            welcomeLabel = "PALETO Mekaniğe Hoşgeldiniz!",
            enabled = true,
            ---------- Receipt system ----------
            useReceiptSystem = false,  -- In the case of "useReceiptSystem" = false everyone will need 
            -- pay for evenry modification and all modifications will be saved on the vehicle. 
            -- In the case of "useReceiptSystem = true" only players who don't have any job from list below "saveUpgrades"
            -- will receive a receipt and not have to pay for modifications. 

            
            saveUpgrades = { 
                jobs = {"sheriff"}, -- If a player has some of these jobs, they will need to pay for every 
                                     -- modification, and all will be saved on the vehicle.
                dutyCheck = false, 
            } ,

            upgradesMenuAccess = {
                jobs = {"sheriff"}, -- If a player has some of these jobs, they will have access to the "upgrades menu" - engine upgrades, brake upgrades...
                dutyCheck = false,
            },
            ------------------------------------
        },
        blip = {
            label = 'PALETO Mekanik',
            coords = vector3(450.06, -976.04, 25.31),
            sprite = 72,
            scale = 0.65,
            color = 27,
            display = 4,
            enabled = false,
        },
        categories = {
            mods = true,
            turbo = true,
            repair = true,
            respray = true,
            liveries = true,
            wheels = true,
            tint = true,
            plate = true,
            extras = true,
            neons = true,
            xenons = true,
            horn = true,
            cosmetics = true,
        },
        drawtextui = {
            text = "Mekanik Alanı"
        },
        restrictions = {
            job = { 'police', 'bcso', 'parkranger', 'sheriff' },
        },
        zones = {
            { coords = vector3(-457.85, 6044.46, 30.92), length = 6.0, width = 4.0, heading = 224.0, minZ = 28.88, maxZ = 35.48 },
        }
    },
    ['police'] = {
        settings = {
            label = 'LSPD Mekanik',
            welcomeLabel = "LSPD Mekaniğe Hoşgeldiniz!",
            enabled = true,
            ---------- Receipt system ----------
            useReceiptSystem = false,  -- In the case of "useReceiptSystem" = false everyone will need 
            -- pay for evenry modification and all modifications will be saved on the vehicle. 
            -- In the case of "useReceiptSystem = true" only players who don't have any job from list below "saveUpgrades"
            -- will receive a receipt and not have to pay for modifications. 

            
            saveUpgrades = { 
                jobs = {"police"}, -- If a player has some of these jobs, they will need to pay for every 
                                     -- modification, and all will be saved on the vehicle.
                dutyCheck = false, 
            } ,

            upgradesMenuAccess = {
                jobs = {"police"}, -- If a player has some of these jobs, they will have access to the "upgrades menu" - engine upgrades, brake upgrades...
                dutyCheck = false,
            },
            ------------------------------------
        },
        blip = {
            label = 'LSPD Mekanik',
            coords = vector3(450.06, -976.04, 25.31),
            sprite = 72,
            scale = 0.65,
            color = 27,
            display = 4,
            enabled = false,
        },
        categories = {
            mods = true,
            turbo = true,
            repair = true,
            respray = true,
            liveries = true,
            wheels = true,
            tint = true,
            plate = true,
            extras = true,
            neons = true,
            xenons = true,
            horn = true,
            cosmetics = true,
        },
        drawtextui = {
            text = "Mekanik Alanı"
        },
        restrictions = {
            job = { 'police', 'bcso', 'parkranger', 'sheriff' },
        },
        zones = {
            { coords = vector3(450.06, -976.04, 25.31), length = 6.0, width = 4.0, heading = 270.0, minZ = 20.88, maxZ = 26.48 },
            { coords = vector3(435.44, -976.17, 25.31), length = 6.0, width = 4.0, heading = 270.0, minZ = 20.88, maxZ = 26.48 },
        }
    },

    ['bcso'] = {
        settings = {
            label = 'BCSO Mekanik',
            welcomeLabel = "BCSO Mekaniğe Hoşgeldiniz!",
            enabled = true,
            ---------- Receipt system ----------
            useReceiptSystem = false,  -- In the case of "useReceiptSystem" = false everyone will need 
            -- pay for evenry modification and all modifications will be saved on the vehicle. 
            -- In the case of "useReceiptSystem = true" only players who don't have any job from list below "saveUpgrades"
            -- will receive a receipt and not have to pay for modifications. 

            
            saveUpgrades = { 
                jobs = {"bcso"}, -- If a player has some of these jobs, they will need to pay for every 
                                     -- modification, and all will be saved on the vehicle.
                dutyCheck = false, 
            } ,

            upgradesMenuAccess = {
                jobs = {"bcso"}, -- If a player has some of these jobs, they will have access to the "upgrades menu" - engine upgrades, brake upgrades...
                dutyCheck = false,
            },
            ------------------------------------
        },
        blip = {
            label = 'LSPD Mekanik',
            coords = vector3(450.06, -976.04, 25.31),
            sprite = 72,
            scale = 0.65,
            color = 27,
            display = 4,
            enabled = false,
        },
        categories = {
            mods = true,
            turbo = true,
            repair = true,
            respray = true,
            liveries = true,
            wheels = true,
            tint = true,
            plate = true,
            extras = true,
            neons = true,
            xenons = true,
            horn = true,
            cosmetics = true,
        },
        drawtextui = {
            text = "Mekanik Alanı"
        },
        restrictions = {
            job = { 'police', 'bcso', 'parkranger', 'sheriff' },
        },
        zones = {
            { coords = vector3(1881.32, 3700.97, 33.54), length = 6.0, width = 4.0, heading = 208.15, minZ = 30.88, maxZ = 36.48 },
        }
    },

    ['parkranger'] = {
        settings = {
            label = 'Park Ranger Mekanik',
            welcomeLabel = "Park Ranger Hoşgeldiniz!",
            enabled = true,
            ---------- Receipt system ----------
            useReceiptSystem = false,  -- In the case of "useReceiptSystem" = false everyone will need 
            -- pay for evenry modification and all modifications will be saved on the vehicle. 
            -- In the case of "useReceiptSystem = true" only players who don't have any job from list below "saveUpgrades"
            -- will receive a receipt and not have to pay for modifications. 

            
            saveUpgrades = { 
                jobs = {"parkranger"}, -- If a player has some of these jobs, they will need to pay for every 
                                     -- modification, and all will be saved on the vehicle.
                dutyCheck = false, 
            } ,

            upgradesMenuAccess = {
                jobs = {"parkranger"}, -- If a player has some of these jobs, they will have access to the "upgrades menu" - engine upgrades, brake upgrades...
                dutyCheck = false,
            },
            ------------------------------------
        },
        blip = {
            label = 'LSPD Mekanik',
            coords = vector3(374.35, 796.41, 187.04),
            sprite = 72,
            scale = 0.65,
            color = 27,
            display = 4,
            enabled = false,
        },
        categories = {
            mods = true,
            turbo = true,
            repair = true,
            respray = true,
            liveries = true,
            wheels = true,
            tint = true,
            plate = true,
            extras = true,
            neons = true,
            xenons = true,
            horn = true,
            cosmetics = true,
        },
        drawtextui = {
            text = "Mekanik Alanı"
        },
        restrictions = {
            job = { 'police', 'bcso', 'parkranger', 'sheriff' },
        },
        zones = {
            { coords = vector3(374.35, 796.41, 187.04), length = 4.0, width = 4.0, heading = 182, minZ = 30.88, maxZ = 36.48 },
        }
    },
}